package com.bluebus.training.busreservationserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusReservationServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusReservationServerApplication.class, args);
	}

}
